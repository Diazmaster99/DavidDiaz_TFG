/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Página principal",url:"index.html"},
{text:"Paquetes",url:"namespaces.html",children:[
{text:"Lista de paquetes",url:"namespaces.html"},
{text:"Miembros de paquete",url:"namespacemembers.html",children:[
{text:"Todos",url:"namespacemembers.html",children:[
{text:"_",url:"namespacemembers.html#index__5F"},
{text:"a",url:"namespacemembers.html#index_a"},
{text:"b",url:"namespacemembers.html#index_b"},
{text:"c",url:"namespacemembers.html#index_c"},
{text:"d",url:"namespacemembers.html#index_d"},
{text:"e",url:"namespacemembers.html#index_e"},
{text:"f",url:"namespacemembers.html#index_f"},
{text:"g",url:"namespacemembers.html#index_g"},
{text:"h",url:"namespacemembers.html#index_h"},
{text:"i",url:"namespacemembers.html#index_i"},
{text:"l",url:"namespacemembers.html#index_l"},
{text:"m",url:"namespacemembers.html#index_m"},
{text:"n",url:"namespacemembers.html#index_n"},
{text:"o",url:"namespacemembers.html#index_o"},
{text:"p",url:"namespacemembers.html#index_p"},
{text:"r",url:"namespacemembers.html#index_r"},
{text:"s",url:"namespacemembers.html#index_s"},
{text:"t",url:"namespacemembers.html#index_t"},
{text:"w",url:"namespacemembers.html#index_w"}]},
{text:"Funciones",url:"namespacemembers_func.html",children:[
{text:"_",url:"namespacemembers_func.html#index__5F"},
{text:"a",url:"namespacemembers_func.html#index_a"},
{text:"b",url:"namespacemembers_func.html#index_b"},
{text:"c",url:"namespacemembers_func.html#index_c"},
{text:"d",url:"namespacemembers_func.html#index_d"},
{text:"e",url:"namespacemembers_func.html#index_e"},
{text:"f",url:"namespacemembers_func.html#index_f"},
{text:"l",url:"namespacemembers_func.html#index_l"},
{text:"m",url:"namespacemembers_func.html#index_m"},
{text:"p",url:"namespacemembers_func.html#index_p"},
{text:"s",url:"namespacemembers_func.html#index_s"},
{text:"t",url:"namespacemembers_func.html#index_t"}]},
{text:"Variables",url:"namespacemembers_vars.html",children:[
{text:"_",url:"namespacemembers_vars.html#index__5F"},
{text:"a",url:"namespacemembers_vars.html#index_a"},
{text:"b",url:"namespacemembers_vars.html#index_b"},
{text:"c",url:"namespacemembers_vars.html#index_c"},
{text:"d",url:"namespacemembers_vars.html#index_d"},
{text:"e",url:"namespacemembers_vars.html#index_e"},
{text:"f",url:"namespacemembers_vars.html#index_f"},
{text:"g",url:"namespacemembers_vars.html#index_g"},
{text:"h",url:"namespacemembers_vars.html#index_h"},
{text:"i",url:"namespacemembers_vars.html#index_i"},
{text:"m",url:"namespacemembers_vars.html#index_m"},
{text:"n",url:"namespacemembers_vars.html#index_n"},
{text:"o",url:"namespacemembers_vars.html#index_o"},
{text:"p",url:"namespacemembers_vars.html#index_p"},
{text:"r",url:"namespacemembers_vars.html#index_r"},
{text:"s",url:"namespacemembers_vars.html#index_s"},
{text:"t",url:"namespacemembers_vars.html#index_t"},
{text:"w",url:"namespacemembers_vars.html#index_w"}]}]}]},
{text:"Clases",url:"annotated.html",children:[
{text:"Lista de clases",url:"annotated.html"},
{text:"Índice de clases",url:"classes.html"},
{text:"Jerarquía de clases",url:"hierarchy.html"},
{text:"Miembros de clases",url:"functions.html",children:[
{text:"Todos",url:"functions.html",children:[
{text:"_",url:"functions.html#index__5F"},
{text:"a",url:"functions.html#index_a"},
{text:"c",url:"functions.html#index_c"},
{text:"e",url:"functions.html#index_e"},
{text:"f",url:"functions.html#index_f"},
{text:"l",url:"functions.html#index_l"},
{text:"m",url:"functions.html#index_m"},
{text:"o",url:"functions.html#index_o"},
{text:"p",url:"functions.html#index_p"},
{text:"r",url:"functions.html#index_r"},
{text:"s",url:"functions.html#index_s"},
{text:"t",url:"functions.html#index_t"},
{text:"w",url:"functions.html#index_w"},
{text:"y",url:"functions.html#index_y"}]},
{text:"Funciones",url:"functions_func.html",children:[
{text:"_",url:"functions_func.html#index__5F"},
{text:"a",url:"functions_func.html#index_a"},
{text:"c",url:"functions_func.html#index_c"},
{text:"e",url:"functions_func.html#index_e"},
{text:"f",url:"functions_func.html#index_f"},
{text:"p",url:"functions_func.html#index_p"},
{text:"r",url:"functions_func.html#index_r"},
{text:"s",url:"functions_func.html#index_s"},
{text:"t",url:"functions_func.html#index_t"},
{text:"w",url:"functions_func.html#index_w"},
{text:"y",url:"functions_func.html#index_y"}]},
{text:"Variables",url:"functions_vars.html",children:[
{text:"_",url:"functions_vars.html#index__5F"},
{text:"a",url:"functions_vars.html#index_a"},
{text:"c",url:"functions_vars.html#index_c"},
{text:"e",url:"functions_vars.html#index_e"},
{text:"l",url:"functions_vars.html#index_l"},
{text:"m",url:"functions_vars.html#index_m"},
{text:"o",url:"functions_vars.html#index_o"},
{text:"p",url:"functions_vars.html#index_p"},
{text:"t",url:"functions_vars.html#index_t"}]}]}]},
{text:"Archivos",url:"files.html",children:[
{text:"Lista de archivos",url:"files.html"}]}]}
